import py2exe
from distutils.core import setup

setup(console=['chooseletter.py'])
